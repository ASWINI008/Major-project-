Ecommerce Website:-

Ecommerce Website using Python Django,HTML,CSS,Javascript.

This website allows you to purchase dresses and shoes online.

Used Technologies:
Python Django,HTML,CSS,Javascript

Steps to use:
1.Download python and IDE
2.Clone the repository by running command 
git clone https://github.com/Ayushparikh-code/Web-dev-mini-projects.git
in your git bash.
3.Run command cd Ecommerce Website

Screenshots:
<img src="C:\Users\user\Pictures\Screenshots\Screenshot (261).png">
<img src="C:\Users\user\Pictures\Screenshots\Screenshot (260).png">